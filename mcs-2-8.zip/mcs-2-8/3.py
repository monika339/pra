import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
df=pd.read_csv('')
df.columns=df.columns.str.strip()
print("Database Info:")
print(df.info())
print("\nFirst few rows:")
print(df.head())
x=df[['Level']]
y=df['Salary']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
linear_regressor=LinearRegression()
linear_regressor.fit(x_train,y_train)
y_pred_linearhb=linear_regressor.predict(x_test)
mse_linear=mean_squared_error(y_test,y_pred_linear)
print(f'\nLinear Regression Mean Squared Error:{mse_linear:.2f}')
plt.scatter(x,y,color='red',label='Actual Data')
plt.plot(x,linear_regressor.predict(x),color='blue',label='Linear Regression')
plt.title('Simple Linear Regression')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.legend()
plt.grid(True)
plt.show()
poly_features=PolynomialFeatures(degree=4)
x_poly_train=poly_features.fit_transform(x_train)
poly_regressor=LinearRegression()
poly_regressor.fit(x_poly_train,y_train)
x_poly_test=poly_features.transform(x_test)
y_pred_poly=poly_regressor.predict(x_poly__test)
mse_poly=mean_squared_error(y_test,y_pred_poly)
print(f'\nPolynomial Regression Mean Squared Error:{mse_poly:.2f}')
x_grid=pd.DataFrame({'Level':np.arange(min(x['Level']),max(x['level']),0.1)})
x_grid_poly=poly_features.transform(x_grid)
plt.scatter(x,y,color='red',label='Actual Data')
plt.plot(x_grid,poly_regressor.predict(x_grid_poly),color='green',label='Polynomial Regression(deg=4)')
plt.title('Polynomial Regression')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.legend()
plt.grid(True)
plt.show()
level_11=pd.DataFrame({'Level':[11]})
level_12=pd.DataFrame({'Level':[12]})
salary_level_11_linear=linear_regressor.predict(level_11)[0]
salary_level_12_linear=linear_regressor.predict(level_12)[0]
salary_level_11_poly=poly_regressor.predict(poly_features.transform(level_11))[0]
salary_level_12_poly=poly_regressor.predict(poly_features.transform(level_12))[0]
print(f'----------------')
print(f'\nLinear Regression Salary Prediction:')
print(f'Level 11: ${salary_level_11_linear:.2f}')
print(f'Level 12: ${salary_level_12_linear:.2f}')

print(f'\nPolynomial Regression Salary Prediction:')
print(f'Level 11: ${salary_level_11_poly:.2f}')
print(f'Level 12: ${salary_level_12_poly:.2f}')

print("\nModel Comparison Summary:")
print(f"Linear Regression MSE :{mse_linear:.2f}")
print(f"Polynomial Regression MSE:{mse_poly:.2f}")
if mse_linear<mse_poly:
    print("Simple Linear Regression is more accurate.")
else:
    print("Polynomial Regression is more accurate.")
                    
      



        
