import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge,Lasso,ElasticNet
from sklearn.metrics import mean_squared_error

data=pd.read_csv(r'/home/kkw-pgii-pc09/Desktop/mcs-2-8/BostonHousing.csv')
data=data[['RM','Price']]

data=data.dropna()
x=data[['RM']]
y=data['Price']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
ridge_model=Ridge(alpha=1.0)
lasso_model=Ridge(alpha=1.0)
elastic_net_model=ElasticNet(alpha=1.0)

ridge_model.fit(x_train,y_train)
lasso_model.fit(x_train,y_train)
elastic_net_model.fit(x_train,y_train)

ridge_predictions=ridge_model.predict(x_test)
lasso_predictions=ridge_model.predict(x_test)
elastic_net_predictions=elastic_net_model.predict(x_test)

ridge_mse=mean_squared_error(y_test,ridge_predictions)
lasso_mse=mean_squared_error(y_test,lasso_predictions)
elastic_net_mse=mean_squared_error(y_test,elastic_net_predictions)

print(f'Ridge Regression MSE: {ridge_mse:.2f}')
print(f'Lasso Regression MSE: {lasso_mse:.2f}')
print(f'Elastic Net Regression MSE: {elastic_net_mse:.2f}')

rooms=pd.DataFrame({'RM':[5]})
predicted_price_ridge=ridge_model.predict(rooms)[0]
predicted_price_lasso=lasso_model.predict(rooms)[0]
predicted_price_elastic_net=elastic_net_model.predict(rooms)[0]

print(f'\nPredicted Price of a house with 5 rooms:')
print(f'Ridge Regression : ${predicted_price_ridge}')
print(f'Lasso Regression : ${predicted_price_lasso}')
print(f'Elastic Net Regression: ${predicted_price_elastic_neta]7*}')

